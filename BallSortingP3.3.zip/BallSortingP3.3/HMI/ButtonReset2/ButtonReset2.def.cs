using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ButtonReset2_HMI;
#endregion ButtonReset2_HMI;

#endregion Definitions;

