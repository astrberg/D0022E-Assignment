using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BufferBottom_HMI;
#endregion BufferBottom_HMI;

#endregion Definitions;

