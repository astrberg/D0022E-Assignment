﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 7/4/2016
 * Time: 3:19 PM
 * 
 */

using System;
using System.Drawing;
using System.Windows.Forms;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.BufferBottom
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
    
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();      
      ball1.Visible = false;
      ball2.Visible = false;
      ball3.Visible = false;
      ball4.Visible = false;
      ball5.Visible = false;
      ball6.Visible = false;
      ball7.Visible = false;
		}
		
		
		void Execute_11ValueChanged(object sender, ValueChangedEventArgs e)
		{
		  short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball1.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball1.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball1.BrushColor = Color.Gray;
  		      break;
			  }
		    ball1.Visible = true;
		  }
		  else
		  {
		    ball1.Visible = false;
		  }
		}
		
		void Execute_12ValueChanged(object sender, ValueChangedEventArgs e)
		{
		  short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball2.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball2.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball2.BrushColor = Color.Gray;
  		      break;
			  }
		    ball2.Visible = true;
		  }
		  else
		  {
		    ball2.Visible = false;
		  }
		}

		
		void Execute_13ValueChanged(object sender, ValueChangedEventArgs e)
		{
			short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball3.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball3.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball3.BrushColor = Color.Gray;
  		      break;
			  }
		    ball3.Visible = true;
		  }
		  else
		  {
		    ball3.Visible = false;
		  }
		}
		
		void Execute_14ValueChanged(object sender, ValueChangedEventArgs e)
		{
			short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball4.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball4.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball4.BrushColor = Color.Gray;
  		      break;
			  }
		    ball4.Visible = true;
		  }
		  else
		  {
		    ball4.Visible = false;
		  }
		}
		
		void Execute_15ValueChanged(object sender, ValueChangedEventArgs e)
		{
			short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball5.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball5.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball5.BrushColor = Color.Gray;
  		      break;
			  }
		    ball5.Visible = true;
		  }
		  else
		  {
		    ball5.Visible = false;
		  }
		}
		
		void Execute_16ValueChanged(object sender, ValueChangedEventArgs e)
		{
			short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball6.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball6.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball6.BrushColor = Color.Gray;
  		      break;
			  }
		    ball6.Visible = true;
		  }
		  else
		  {
		    ball6.Visible = false;
		  }
		}
		
		void Execute_17ValueChanged(object sender, ValueChangedEventArgs e)
		{
			short material = (short)e.Value;
		  if (material > 0)
		  {
		    switch (material)
			  {
  		    case 1:
  		      ball7.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball7.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball7.BrushColor = Color.Gray;
  		      break;
			  }
		    ball7.Visible = true;
		  }
		  else
		  {
		    ball7.Visible = false;
		  }
		}
	}
}
