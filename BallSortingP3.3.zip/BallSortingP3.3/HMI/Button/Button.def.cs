﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
