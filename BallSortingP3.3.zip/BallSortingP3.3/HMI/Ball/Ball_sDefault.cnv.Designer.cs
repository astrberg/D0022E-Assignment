﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/8/2016
 * Time: 3:44 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Ball
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ball = new NxtControl.GuiFramework.Ellipse();
			this.PosX = new System.HMI.Symbols.Base.Execute<float>();
			this.PosY = new System.HMI.Symbols.Base.Execute<float>();
			// 
			// ball
			// 
			this.ball.Bounds = new NxtControl.Drawing.RectF(((float)(0)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball.Name = "ball";
			// 
			// PosX
			// 
			this.PosX.BeginInit();
			this.PosX.AngleIgnore = false;
			this.PosX.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 28, 68);
			this.PosX.IsOnlyInput = true;
			this.PosX.Name = "PosX";
			this.PosX.TagName = "PosX";
			this.PosX.Value = 0F;
			this.PosX.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.PosXValueChanged);
			this.PosX.EndInit();
			// 
			// PosY
			// 
			this.PosY.BeginInit();
			this.PosY.AngleIgnore = false;
			this.PosY.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 28, 93);
			this.PosY.IsOnlyInput = true;
			this.PosY.Name = "PosY";
			this.PosY.TagName = "PosY";
			this.PosY.Value = 0F;
			this.PosY.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.PosYValueChanged);
			this.PosY.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.ball,
									this.PosX,
									this.PosY});
			this.SymbolSize = new System.Drawing.Size(153, 206);
		}
		private System.HMI.Symbols.Base.Execute<float> PosY;
		private System.HMI.Symbols.Base.Execute<float> PosX;
		private NxtControl.GuiFramework.Ellipse ball;
		#endregion
	}
}
