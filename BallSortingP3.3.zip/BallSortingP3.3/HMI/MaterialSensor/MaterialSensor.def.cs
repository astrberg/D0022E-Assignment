using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region MaterialSensor_HMI;
#endregion MaterialSensor_HMI;

#endregion Definitions;

