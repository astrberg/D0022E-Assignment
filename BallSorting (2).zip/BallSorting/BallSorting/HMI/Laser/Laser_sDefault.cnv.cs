﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/15/2016
 * Time: 10:15 AM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Laser
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
      this.CHG_Fired += CHG_Fired_EventHandler;
		}
		
		void CHG_Fired_EventHandler(object sender, HMI.Main.Symbols.Laser.CHGEventArgs ea)
		{
		  NxtControl.Drawing.PointF myPoint = laser.EndPoint;
		  myPoint.Y = (double)ea.LaserPos + 63.0;
		  laser.EndPoint = myPoint;
		}
	}
}
