﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 6:25 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pipeT1 = new NxtControl.GuiFramework.PipeT();
			this.pipeT2 = new NxtControl.GuiFramework.PipeT();
			this.pipe1 = new NxtControl.GuiFramework.Pipe();
			this.pipeT3 = new NxtControl.GuiFramework.PipeT();
			this.pipe2 = new NxtControl.GuiFramework.Pipe();
			this.pipe3 = new NxtControl.GuiFramework.Pipe();
			this.pipe4 = new NxtControl.GuiFramework.Pipe();
			this.Ball1 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball2 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball3 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball4 = new HMI.Main.Symbols.Ball.sDefault();
			this.ButtonReset = new HMI.Main.Symbols.ButtonReset.sDefault();
			this.LaserSensor = new HMI.Main.Symbols.Laser.sDefault();
			this.MaterialSensor = new HMI.Main.Symbols.MaterialSensor.sDefault();
			this.Gate1 = new HMI.Main.Symbols.CylinderGate.sDefault();
			this.Gate2 = new HMI.Main.Symbols.CylinderGate.sDefault();
			this.BufferBottom = new HMI.Main.Symbols.BufferBottom.sDefault();
			this.Buffer2 = new HMI.Main.Symbols.Buffer.sDefault();
			this.ButtGate2 = new HMI.Main.Symbols.Button.sDefault();
			this.Buffer1 = new HMI.Main.Symbols.Buffer.sDefault();
			this.ButtGate1 = new HMI.Main.Symbols.Button.sDefault();
			this.ButtEject = new HMI.Main.Symbols.Button.sDefault();
			this.CylinderEjector = new HMI.Main.Symbols.CylinderEjector.sDefault();
			this.RetractedSensor = new HMI.Main.Symbols.Sensor.sDefault();
			this.ExtendSensor = new HMI.Main.Symbols.Sensor.sDefault();
			this.ResetLabel = new NxtControl.GuiFramework.Label();
			this.label1 = new NxtControl.GuiFramework.Label();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.label3 = new NxtControl.GuiFramework.Label();
			// 
			// pipeT1
			// 
			this.pipeT1.Angle = 90F;
			this.pipeT1.Bounds = new NxtControl.Drawing.RectF(((float)(266)), ((float)(319)), ((float)(328)), ((float)(46)));
			this.pipeT1.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipeT1.Name = "pipeT1";
			this.pipeT1.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipeT1.PipeWidth = 40;
			// 
			// pipeT2
			// 
			this.pipeT2.Bounds = new NxtControl.Drawing.RectF(((float)(349)), ((float)(1)), ((float)(46)), ((float)(200)));
			this.pipeT2.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipeT2.Name = "pipeT2";
			this.pipeT2.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipeT2.PipeWidth = 40;
			// 
			// pipe1
			// 
			this.pipe1.Bounds = new NxtControl.Drawing.RectF(((float)(286)), ((float)(181)), ((float)(66)), ((float)(138)));
			this.pipe1.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe1.Name = "pipe1";
			this.pipe1.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe1.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(352, 181),
									new NxtControl.Drawing.PointF(287, 181),
									new NxtControl.Drawing.PointF(286, 319)});
			this.pipe1.Width = 40;
			// 
			// pipeT3
			// 
			this.pipeT3.Angle = 90F;
			this.pipeT3.Bounds = new NxtControl.Drawing.RectF(((float)(266)), ((float)(486)), ((float)(328)), ((float)(46)));
			this.pipeT3.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipeT3.Name = "pipeT3";
			this.pipeT3.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipeT3.PipeWidth = 40;
			// 
			// pipe2
			// 
			this.pipe2.Bounds = new NxtControl.Drawing.RectF(((float)(9)), ((float)(531)), ((float)(277)), ((float)(141)));
			this.pipe2.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe2.Name = "pipe2";
			this.pipe2.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe2.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(286, 531),
									new NxtControl.Drawing.PointF(286, 672),
									new NxtControl.Drawing.PointF(9, 672)});
			this.pipe2.Width = 40;
			// 
			// pipe3
			// 
			this.pipe3.Bounds = new NxtControl.Drawing.RectF(((float)(286)), ((float)(363)), ((float)(0)), ((float)(123)));
			this.pipe3.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe3.Name = "pipe3";
			this.pipe3.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe3.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(286, 363),
									new NxtControl.Drawing.PointF(286, 486)});
			this.pipe3.Width = 40;
			// 
			// pipe4
			// 
			this.pipe4.Bounds = new NxtControl.Drawing.RectF(((float)(372)), ((float)(0)), ((float)(0)), ((float)(39.999999999999993)));
			this.pipe4.InnerColor = new NxtControl.Drawing.Color(((byte)(154)), ((byte)(154)), ((byte)(154)));
			this.pipe4.Name = "pipe4";
			this.pipe4.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe4.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(372, 0),
									new NxtControl.Drawing.PointF(372, 39.999999999999993)});
			this.pipe4.Width = 40;
			// 
			// Ball1
			// 
			this.Ball1.BeginInit();
			this.Ball1.AngleIgnore = false;
			this.Ball1.Name = "Ball1";
			this.Ball1.SecurityToken = ((uint)(4294967295u));
			this.Ball1.TagName = "BE4C58EC5BC1B409.Balls.Ball1";
			this.Ball1.EndInit();
			// 
			// Ball2
			// 
			this.Ball2.BeginInit();
			this.Ball2.AngleIgnore = false;
			this.Ball2.Name = "Ball2";
			this.Ball2.SecurityToken = ((uint)(4294967295u));
			this.Ball2.TagName = "BE4C58EC5BC1B409.Balls.Ball2";
			this.Ball2.EndInit();
			// 
			// Ball3
			// 
			this.Ball3.BeginInit();
			this.Ball3.AngleIgnore = false;
			this.Ball3.Name = "Ball3";
			this.Ball3.SecurityToken = ((uint)(4294967295u));
			this.Ball3.TagName = "BE4C58EC5BC1B409.Balls.Ball3";
			this.Ball3.EndInit();
			// 
			// Ball4
			// 
			this.Ball4.BeginInit();
			this.Ball4.AngleIgnore = false;
			this.Ball4.Name = "Ball4";
			this.Ball4.SecurityToken = ((uint)(4294967295u));
			this.Ball4.TagName = "BE4C58EC5BC1B409.Balls.Ball4";
			this.Ball4.EndInit();
			// 
			// ButtonReset
			// 
			this.ButtonReset.BeginInit();
			this.ButtonReset.AngleIgnore = false;
			this.ButtonReset.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 79, 87);
			this.ButtonReset.Name = "ButtonReset";
			this.ButtonReset.SecurityToken = ((uint)(4294967295u));
			this.ButtonReset.TagName = "BE4C58EC5BC1B409.FB1";
			this.ButtonReset.EndInit();
			// 
			// LaserSensor
			// 
			this.LaserSensor.BeginInit();
			this.LaserSensor.AngleIgnore = false;
			this.LaserSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 269, 125);
			this.LaserSensor.Name = "LaserSensor";
			this.LaserSensor.SecurityToken = ((uint)(4294967295u));
			this.LaserSensor.TagName = "BE4C58EC5BC1B409.FB3.FB1";
			this.LaserSensor.EndInit();
			// 
			// MaterialSensor
			// 
			this.MaterialSensor.BeginInit();
			this.MaterialSensor.AngleIgnore = false;
			this.MaterialSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 323, 198);
			this.MaterialSensor.Name = "MaterialSensor";
			this.MaterialSensor.SecurityToken = ((uint)(4294967295u));
			this.MaterialSensor.TagName = "BE4C58EC5BC1B409.FB3.FB2";
			this.MaterialSensor.EndInit();
			// 
			// Gate1
			// 
			this.Gate1.BeginInit();
			this.Gate1.AngleIgnore = false;
			this.Gate1.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 130, 317);
			this.Gate1.Name = "Gate1";
			this.Gate1.SecurityToken = ((uint)(4294967295u));
			this.Gate1.TagName = "BE4C58EC5BC1B409.Gate1";
			this.Gate1.EndInit();
			// 
			// Gate2
			// 
			this.Gate2.BeginInit();
			this.Gate2.AngleIgnore = false;
			this.Gate2.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 128, 486);
			this.Gate2.Name = "Gate2";
			this.Gate2.SecurityToken = ((uint)(4294967295u));
			this.Gate2.TagName = "BE4C58EC5BC1B409.Gate2";
			this.Gate2.EndInit();
			// 
			// BufferBottom
			// 
			this.BufferBottom.BeginInit();
			this.BufferBottom.AngleIgnore = false;
			this.BufferBottom.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 9, 653);
			this.BufferBottom.Name = "BufferBottom";
			this.BufferBottom.SecurityToken = ((uint)(4294967295u));
			this.BufferBottom.TagName = "BE4C58EC5BC1B409.PhysicsModel.FB2";
			this.BufferBottom.EndInit();
			// 
			// Buffer2
			// 
			this.Buffer2.BeginInit();
			this.Buffer2.AngleIgnore = false;
			this.Buffer2.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 307, 490);
			this.Buffer2.Name = "Buffer2";
			this.Buffer2.SecurityToken = ((uint)(4294967295u));
			this.Buffer2.TagName = "BE4C58EC5BC1B409.PhysicsModel.Buffer2";
			this.Buffer2.EndInit();
			// 
			// ButtGate2
			// 
			this.ButtGate2.BeginInit();
			this.ButtGate2.AngleIgnore = false;
			this.ButtGate2.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 17, 495);
			this.ButtGate2.Name = "ButtGate2";
			this.ButtGate2.SecurityToken = ((uint)(4294967295u));
			this.ButtGate2.TagName = "BE4C58EC5BC1B409.ButtGate2";
			this.ButtGate2.EndInit();
			// 
			// Buffer1
			// 
			this.Buffer1.BeginInit();
			this.Buffer1.AngleIgnore = false;
			this.Buffer1.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 306, 324);
			this.Buffer1.Name = "Buffer1";
			this.Buffer1.SecurityToken = ((uint)(4294967295u));
			this.Buffer1.TagName = "BE4C58EC5BC1B409.PhysicsModel.Buffer1";
			this.Buffer1.EndInit();
			// 
			// ButtGate1
			// 
			this.ButtGate1.BeginInit();
			this.ButtGate1.AngleIgnore = false;
			this.ButtGate1.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 21, 323);
			this.ButtGate1.Name = "ButtGate1";
			this.ButtGate1.SecurityToken = ((uint)(4294967295u));
			this.ButtGate1.TagName = "BE4C58EC5BC1B409.ButtGate1";
			this.ButtGate1.EndInit();
			// 
			// ButtEject
			// 
			this.ButtEject.BeginInit();
			this.ButtEject.AngleIgnore = false;
			this.ButtEject.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 649, 166);
			this.ButtEject.Name = "ButtEject";
			this.ButtEject.SecurityToken = ((uint)(4294967295u));
			this.ButtEject.TagName = "BE4C58EC5BC1B409.ButtonEject";
			this.ButtEject.EndInit();
			// 
			// CylinderEjector
			// 
			this.CylinderEjector.BeginInit();
			this.CylinderEjector.AngleIgnore = false;
			this.CylinderEjector.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 394, 157);
			this.CylinderEjector.Name = "CylinderEjector";
			this.CylinderEjector.SecurityToken = ((uint)(4294967295u));
			this.CylinderEjector.TagName = "BE4C58EC5BC1B409.Eject";
			this.CylinderEjector.EndInit();
			// 
			// RetractedSensor
			// 
			this.RetractedSensor.BeginInit();
			this.RetractedSensor.AngleIgnore = false;
			this.RetractedSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 594, 136);
			this.RetractedSensor.Name = "RetractedSensor";
			this.RetractedSensor.SecurityToken = ((uint)(4294967295u));
			this.RetractedSensor.TagName = "BE4C58EC5BC1B409.FB3.Retracted";
			this.RetractedSensor.EndInit();
			// 
			// ExtendSensor
			// 
			this.ExtendSensor.BeginInit();
			this.ExtendSensor.AngleIgnore = false;
			this.ExtendSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 484, 136);
			this.ExtendSensor.Name = "ExtendSensor";
			this.ExtendSensor.SecurityToken = ((uint)(4294967295u));
			this.ExtendSensor.TagName = "BE4C58EC5BC1B409.FB3.Extended";
			this.ExtendSensor.EndInit();
			// 
			// ResetLabel
			// 
			this.ResetLabel.AngleIgnore = true;
			this.ResetLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.ResetLabel.Bounds = new NxtControl.Drawing.RectF(((float)(65)), ((float)(164)), ((float)(98)), ((float)(25)));
			this.ResetLabel.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.ResetLabel.Font = new NxtControl.Drawing.Font("Lucida Sans", 14.25F, System.Drawing.FontStyle.Regular);
			this.ResetLabel.Name = "ResetLabel";
			this.ResetLabel.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.ResetLabel.Text = "Reset";
			this.ResetLabel.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.ResetLabel.TextAutoSizeHorizontalOffset = 10;
			this.ResetLabel.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.ResetLabel.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(24)), ((float)(356)), ((float)(79)), ((float)(48)));
			this.label1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label1.Font = new NxtControl.Drawing.Font("3DS Fonticon", 12F, System.Drawing.FontStyle.Regular);
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "Extend/ Retract";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(18)), ((float)(533)), ((float)(79)), ((float)(48)));
			this.label2.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label2.Font = new NxtControl.Drawing.Font("3DS Fonticon", 12F, System.Drawing.FontStyle.Regular);
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "Extend/ Retract";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(647)), ((float)(199)), ((float)(79)), ((float)(48)));
			this.label3.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label3.Font = new NxtControl.Drawing.Font("Berlin Sans FB", 14.25F, System.Drawing.FontStyle.Regular);
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "Extend/Retract";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// Canvas1
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0)), ((float)(0)), ((float)(800)), ((float)(720)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))));
			this.Name = "Canvas1";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.pipeT1,
									this.pipeT2,
									this.pipe1,
									this.pipeT3,
									this.pipe2,
									this.pipe3,
									this.pipe4,
									this.Ball1,
									this.Ball2,
									this.Ball3,
									this.Ball4,
									this.ButtonReset,
									this.LaserSensor,
									this.MaterialSensor,
									this.Gate1,
									this.Gate2,
									this.BufferBottom,
									this.Buffer2,
									this.ButtGate2,
									this.Buffer1,
									this.ButtGate1,
									this.ButtEject,
									this.CylinderEjector,
									this.RetractedSensor,
									this.ExtendSensor,
									this.ResetLabel,
									this.label1,
									this.label2,
									this.label3});
			this.Size = new System.Drawing.Size(800, 720);
		}
		private NxtControl.GuiFramework.Label label3;
		private NxtControl.GuiFramework.Label label2;
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Label ResetLabel;
		private HMI.Main.Symbols.Sensor.sDefault ExtendSensor;
		private HMI.Main.Symbols.Sensor.sDefault RetractedSensor;
		private HMI.Main.Symbols.CylinderEjector.sDefault CylinderEjector;
		private HMI.Main.Symbols.Button.sDefault ButtEject;
		private HMI.Main.Symbols.Button.sDefault ButtGate1;
		private HMI.Main.Symbols.Buffer.sDefault Buffer1;
		private HMI.Main.Symbols.Button.sDefault ButtGate2;
		private HMI.Main.Symbols.Buffer.sDefault Buffer2;
		private HMI.Main.Symbols.BufferBottom.sDefault BufferBottom;
		private HMI.Main.Symbols.CylinderGate.sDefault Gate2;
		private HMI.Main.Symbols.CylinderGate.sDefault Gate1;
		private HMI.Main.Symbols.MaterialSensor.sDefault MaterialSensor;
		private HMI.Main.Symbols.Laser.sDefault LaserSensor;
		private HMI.Main.Symbols.ButtonReset.sDefault ButtonReset;
		private HMI.Main.Symbols.Ball.sDefault Ball4;
		private HMI.Main.Symbols.Ball.sDefault Ball3;
		private HMI.Main.Symbols.Ball.sDefault Ball2;
		private HMI.Main.Symbols.Ball.sDefault Ball1;
		private NxtControl.GuiFramework.Pipe pipe4;
		private NxtControl.GuiFramework.Pipe pipe3;
		private NxtControl.GuiFramework.Pipe pipe2;
		private NxtControl.GuiFramework.PipeT pipeT3;
		private NxtControl.GuiFramework.Pipe pipe1;
		private NxtControl.GuiFramework.PipeT pipeT2;
		private NxtControl.GuiFramework.PipeT pipeT1;
		#endregion
	}
}
