using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ButtonReset_HMI;
#endregion ButtonReset_HMI;

#endregion Definitions;

