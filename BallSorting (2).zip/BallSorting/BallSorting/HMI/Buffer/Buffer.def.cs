﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 7/7/2016
 * Time: 3:19 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
