﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Button
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.checkButton1 = new System.HMI.Symbols.Base.CheckButton();
			// 
			// checkButton1
			// 
			this.checkButton1.BeginInit();
			this.checkButton1.AngleIgnore = false;
			this.checkButton1.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 38D, 23D);
			this.checkButton1.FalseBrush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(1)), ((byte)(23))));
			this.checkButton1.FalseImage = new NxtControl.Drawing.ImageHolder();
			this.checkButton1.FalseImageDisabled = new NxtControl.Drawing.ImageHolder();
			this.checkButton1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold);
			this.checkButton1.Name = "checkButton1";
			this.checkButton1.TagName = "FWD";
			this.checkButton1.TextColorFalse = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.checkButton1.TextColorTrue = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.checkButton1.TextDisabledColor = new NxtControl.Drawing.Color("Ele110kV");
			this.checkButton1.TrueBrush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(29)), ((byte)(185)), ((byte)(84))));
			this.checkButton1.TrueImage = new NxtControl.Drawing.ImageHolder();
			this.checkButton1.TrueImageDisabled = new NxtControl.Drawing.ImageHolder();
			this.checkButton1.Value = false;
			this.checkButton1.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.checkButton1});
			this.SymbolSize = new System.Drawing.Size(159, 105);
		}
		private System.HMI.Symbols.Base.CheckButton checkButton1;
		#endregion
	}
}
