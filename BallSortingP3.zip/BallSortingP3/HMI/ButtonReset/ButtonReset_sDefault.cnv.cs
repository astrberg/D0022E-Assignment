﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */

using System;
using System.Drawing;
using System.Windows.Forms;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.ButtonReset
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		
		void Ellipse1Click(object sender, EventArgs e)
		{
		  /*
		  DialogResult confirmationBox = MessageBox.Show("Do you want to reset?", "Reset system", MessageBoxButtons.YesNo);
		  if(confirmationBox == DialogResult.Yes) {
		    this.FireEvent_CHG();
		  
		  }
		  */
		  
		  
		  
		}
		
	}
}
