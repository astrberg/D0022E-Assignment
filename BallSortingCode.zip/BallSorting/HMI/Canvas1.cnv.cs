﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 6:25 PM
 * 
 */

using System;
using System.Drawing;
using Microsoft.VisualBasic;
using NxtControl.GuiFramework;
using System.Timers;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas1.
	/// </summary>
	public partial class Canvas1 : NxtControl.GuiFramework.HMICanvas
	{
	  public bool showHelp = false;
		public Canvas1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			helpDialogBox.Visible = false;
		}
		
		static void DelayAction(int t, Action action) {
		  //System.Timers.Timer aj = new System.Timers.ElapsedEventArgs();
		}

		
		void ButtonHelpClick(object sender, EventArgs e)
		{
		  if(!showHelp) {
		    showHelp = true;
		    helpDialogBox.Visible = true;
		    
		  } else {
		    showHelp = false;
		    helpDialogBox.Visible = false;
		  }
		}
		
		void DrawnButton1Click(object sender, EventArgs e)
		{
		  System.Timers.Timer timer;
		  //Stopwatch sw = new Stopwatch();   fanns inte, importa library?
		  //fixa error hantering om man inte valt value på nån
  	  int indexZero = valueOne.SelectedIndex;
  	  int indexOne = valueTwo.SelectedIndex;
  	  int indexTwo = valueThree.SelectedIndex;
  	  //bool a = true;
  	  
    	  if(indexZero != 0) {
    	    timer = new System.Timers.Timer(1000);
    	    //timer.Elapsed += OnTimedEvent;
    	    timer.AutoReset = true;
    	    timer.Start();
    	    
    	    //timer.
    	    
      	    if(timer.Enabled == false){
      	      a = false;
      	      ButtGate1.FireEvent_CHG(true);
      	    }
      	    //for(int i = 0; i <= indexZero; i++) {
      	      //ButtEject.FireEvent_CHG(true);
      	      
      	    //}
  	    }
  	  
  	  if(indexOne != 0) {
  	    
  	  }
  	  
  	  if(indexTwo != 0) {
  	    
  	  }
  	  //ButtGate2.FireEvent_CHG(true);
  	  //ButtEject.FireEvent_CHG(true);
		}
	}
}

