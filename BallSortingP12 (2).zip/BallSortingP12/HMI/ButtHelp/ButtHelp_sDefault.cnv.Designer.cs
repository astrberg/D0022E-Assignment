﻿/*
 * Created by nxtSTUDIO.
 * User: A1203-admin
 * Date: 10/10/2018
 * Time: 2:46 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.ButtHelp
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ellipse1 = new NxtControl.GuiFramework.Ellipse();
			this.ellipse2 = new NxtControl.GuiFramework.Ellipse();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.arc1 = new NxtControl.GuiFramework.Arc();
			// 
			// ellipse1
			// 
			this.ellipse1.Bounds = new NxtControl.Drawing.RectF(((float)(230D)), ((float)(204D)), ((float)(130D)), ((float)(130D)));
			this.ellipse1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(32)), ((byte)(214)), ((byte)(88))));
			this.ellipse1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ellipse1.Name = "ellipse1";
			// 
			// ellipse2
			// 
			this.ellipse2.Bounds = new NxtControl.Drawing.RectF(((float)(288D)), ((float)(307D)), ((float)(15D)), ((float)(15D)));
			this.ellipse2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.ellipse2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ellipse2.Name = "ellipse2";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(295D, 274D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 7F, NxtControl.Drawing.DashStyle.Solid);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(295D, 302D);
			// 
			// arc1
			// 
			this.arc1.Bounds = new NxtControl.Drawing.RectF(((float)(271D)), ((float)(227D)), ((float)(50D)), ((float)(50D)));
			this.arc1.Center = new NxtControl.Drawing.PointF(296D, 252D);
			this.arc1.Name = "arc1";
			this.arc1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 7F, NxtControl.Drawing.DashStyle.Solid);
			this.arc1.RadiusX = 25D;
			this.arc1.RadiusY = 25D;
			this.arc1.StartAngle = 200D;
			this.arc1.SweepAngle = 249.68027219822778D;
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.ellipse1,
									this.ellipse2,
									this.line1,
									this.arc1});
			this.SymbolSize = new System.Drawing.Size(600, 400);
		}
		private NxtControl.GuiFramework.Arc arc1;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Ellipse ellipse2;
		private NxtControl.GuiFramework.Ellipse ellipse1;
		#endregion
	}
}
