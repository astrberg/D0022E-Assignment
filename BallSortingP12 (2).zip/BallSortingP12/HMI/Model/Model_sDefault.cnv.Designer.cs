﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/8/2016
 * Time: 2:52 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Model
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      			this.Name = "sDefault";
		}
		#endregion
	}
}
