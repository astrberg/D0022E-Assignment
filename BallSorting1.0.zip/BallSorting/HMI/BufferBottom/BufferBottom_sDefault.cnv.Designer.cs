﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 7/7/2016
 * Time: 3:19 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.BufferBottom
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ball1 = new NxtControl.GuiFramework.Ellipse();
			this.ball2 = new NxtControl.GuiFramework.Ellipse();
			this.ball3 = new NxtControl.GuiFramework.Ellipse();
			this.ball4 = new NxtControl.GuiFramework.Ellipse();
			this.ball5 = new NxtControl.GuiFramework.Ellipse();
			this.ball6 = new NxtControl.GuiFramework.Ellipse();
			this.ball7 = new NxtControl.GuiFramework.Ellipse();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.execute_11 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_12 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_13 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_14 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_15 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_16 = new System.HMI.Symbols.Base.Execute<short>();
			this.execute_17 = new System.HMI.Symbols.Base.Execute<short>();
			// 
			// ball1
			// 
			this.ball1.Bounds = new NxtControl.Drawing.RectF(((float)(0)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball1.Name = "ball1";
			// 
			// ball2
			// 
			this.ball2.Bounds = new NxtControl.Drawing.RectF(((float)(36)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball2.Name = "ball2";
			// 
			// ball3
			// 
			this.ball3.Bounds = new NxtControl.Drawing.RectF(((float)(72)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball3.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball3.Name = "ball3";
			// 
			// ball4
			// 
			this.ball4.Bounds = new NxtControl.Drawing.RectF(((float)(108)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball4.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball4.Name = "ball4";
			// 
			// ball5
			// 
			this.ball5.Bounds = new NxtControl.Drawing.RectF(((float)(144)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball5.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball5.Name = "ball5";
			// 
			// ball6
			// 
			this.ball6.Bounds = new NxtControl.Drawing.RectF(((float)(180)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball6.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball6.Name = "ball6";
			// 
			// ball7
			// 
			this.ball7.Bounds = new NxtControl.Drawing.RectF(((float)(216)), ((float)(0)), ((float)(36)), ((float)(36)));
			this.ball7.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ball7.Name = "ball7";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(252, 37);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(0, 37);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(0, 1);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(0, 37);
			// 
			// execute_11
			// 
			this.execute_11.BeginInit();
			this.execute_11.AngleIgnore = false;
			this.execute_11.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 29, 50);
			this.execute_11.IsOnlyInput = true;
			this.execute_11.Name = "execute_11";
			this.execute_11.TagName = "Ball1";
			this.execute_11.Value = ((short)(0));
			this.execute_11.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_11ValueChanged);
			this.execute_11.EndInit();
			// 
			// execute_12
			// 
			this.execute_12.BeginInit();
			this.execute_12.AngleIgnore = false;
			this.execute_12.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 26, 72);
			this.execute_12.IsOnlyInput = true;
			this.execute_12.Name = "execute_12";
			this.execute_12.TagName = "Ball2";
			this.execute_12.Value = ((short)(0));
			this.execute_12.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_12ValueChanged);
			this.execute_12.EndInit();
			// 
			// execute_13
			// 
			this.execute_13.BeginInit();
			this.execute_13.AngleIgnore = false;
			this.execute_13.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 26, 85);
			this.execute_13.IsOnlyInput = true;
			this.execute_13.Name = "execute_13";
			this.execute_13.TagName = "Ball3";
			this.execute_13.Value = ((short)(0));
			this.execute_13.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_13ValueChanged);
			this.execute_13.EndInit();
			// 
			// execute_14
			// 
			this.execute_14.BeginInit();
			this.execute_14.AngleIgnore = false;
			this.execute_14.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 25, 104);
			this.execute_14.IsOnlyInput = true;
			this.execute_14.Name = "execute_14";
			this.execute_14.TagName = "Ball4";
			this.execute_14.Value = ((short)(0));
			this.execute_14.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_14ValueChanged);
			this.execute_14.EndInit();
			// 
			// execute_15
			// 
			this.execute_15.BeginInit();
			this.execute_15.AngleIgnore = false;
			this.execute_15.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 30, 123);
			this.execute_15.IsOnlyInput = true;
			this.execute_15.Name = "execute_15";
			this.execute_15.TagName = "Ball5";
			this.execute_15.Value = ((short)(0));
			this.execute_15.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_15ValueChanged);
			this.execute_15.EndInit();
			// 
			// execute_16
			// 
			this.execute_16.BeginInit();
			this.execute_16.AngleIgnore = false;
			this.execute_16.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 20, 138);
			this.execute_16.IsOnlyInput = true;
			this.execute_16.Name = "execute_16";
			this.execute_16.TagName = "Ball6";
			this.execute_16.Value = ((short)(0));
			this.execute_16.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_16ValueChanged);
			this.execute_16.EndInit();
			// 
			// execute_17
			// 
			this.execute_17.BeginInit();
			this.execute_17.AngleIgnore = false;
			this.execute_17.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 27, 160);
			this.execute_17.IsOnlyInput = true;
			this.execute_17.Name = "execute_17";
			this.execute_17.TagName = "Ball7";
			this.execute_17.Value = ((short)(0));
			this.execute_17.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Execute_17ValueChanged);
			this.execute_17.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.ball1,
									this.ball2,
									this.ball3,
									this.ball4,
									this.ball5,
									this.ball6,
									this.ball7,
									this.line1,
									this.line2,
									this.execute_11,
									this.execute_12,
									this.execute_13,
									this.execute_14,
									this.execute_15,
									this.execute_16,
									this.execute_17});
			this.SymbolSize = new System.Drawing.Size(312, 245);
		}
		private System.HMI.Symbols.Base.Execute<short> execute_17;
		private System.HMI.Symbols.Base.Execute<short> execute_16;
		private System.HMI.Symbols.Base.Execute<short> execute_15;
		private System.HMI.Symbols.Base.Execute<short> execute_14;
		private System.HMI.Symbols.Base.Execute<short> execute_13;
		private System.HMI.Symbols.Base.Execute<short> execute_12;
		private System.HMI.Symbols.Base.Execute<short> execute_11;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Ellipse ball1;
		private NxtControl.GuiFramework.Ellipse ball2;
		private NxtControl.GuiFramework.Ellipse ball3;
		private NxtControl.GuiFramework.Ellipse ball4;
		private NxtControl.GuiFramework.Ellipse ball5;
		private NxtControl.GuiFramework.Ellipse ball6;
		private NxtControl.GuiFramework.Ellipse ball7;
		#endregion
	}
}
