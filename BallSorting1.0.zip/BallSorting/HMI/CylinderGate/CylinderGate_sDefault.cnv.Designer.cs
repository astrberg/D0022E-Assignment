﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/25/2016
 * Time: 10:19 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.CylinderGate
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle14 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle13 = new NxtControl.GuiFramework.Rectangle();
			this.POS = new System.HMI.Symbols.Base.Execute<float>();
			this.cylinder = new NxtControl.GuiFramework.Group();
			this.polygon1 = new NxtControl.GuiFramework.Polygon();
			this.rod = new NxtControl.GuiFramework.Group();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(30)), ((float)(35)), ((float)(10)), ((float)(40)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(130)), ((byte)(130)), ((byte)(130))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalCenter));
			this.rectangle1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(40)), ((float)(41)), ((float)(60)), ((float)(30)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalCenter));
			this.rectangle4.FillDirection = NxtControl.Drawing.FillDirection.RightToLeft;
			this.rectangle4.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle4.Name = "rectangle4";
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(100)), ((float)(35)), ((float)(10)), ((float)(40)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(130)), ((byte)(130)), ((byte)(130))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalCenter));
			this.rectangle5.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle5.Name = "rectangle5";
			// 
			// rectangle14
			// 
			this.rectangle14.Bounds = new NxtControl.Drawing.RectF(((float)(110)), ((float)(49)), ((float)(10)), ((float)(14)));
			this.rectangle14.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(114)), ((byte)(114))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalCenter));
			this.rectangle14.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle14.Name = "rectangle14";
			// 
			// rectangle13
			// 
			this.rectangle13.Bounds = new NxtControl.Drawing.RectF(((float)(45)), ((float)(52)), ((float)(80)), ((float)(8)));
			this.rectangle13.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalCenter));
			this.rectangle13.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle13.Name = "rectangle13";
			// 
			// POS
			// 
			this.POS.BeginInit();
			this.POS.AngleIgnore = false;
			this.POS.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 45, 93);
			this.POS.IsOnlyInput = true;
			this.POS.Name = "POS";
			this.POS.TagName = "POS";
			this.POS.Value = 0F;
			this.POS.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.POSValueChanged);
			this.POS.EndInit();
			// 
			// cylinder
			// 
			this.cylinder.BeginInit();
			this.cylinder.Name = "cylinder";
			this.cylinder.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.rectangle4,
									this.rectangle1,
									this.rectangle14,
									this.rectangle5});
			this.cylinder.EndInit();
			// 
			// polygon1
			// 
			this.polygon1.Bounds = new NxtControl.Drawing.RectF(((float)(125)), ((float)(36)), ((float)(40)), ((float)(39)));
			this.polygon1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(182)), ((byte)(174)), ((byte)(166))));
			this.polygon1.Closed = true;
			this.polygon1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.polygon1.Name = "polygon1";
			this.polygon1.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(125, 36),
									new NxtControl.Drawing.PointF(125, 75),
									new NxtControl.Drawing.PointF(165, 75),
									new NxtControl.Drawing.PointF(151, 73),
									new NxtControl.Drawing.PointF(137, 70),
									new NxtControl.Drawing.PointF(132, 67),
									new NxtControl.Drawing.PointF(129, 62),
									new NxtControl.Drawing.PointF(127, 54)});
			// 
			// rod
			// 
			this.rod.BeginInit();
			this.rod.Name = "rod";
			this.rod.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.rectangle13,
									this.polygon1});
			this.rod.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.POS,
									this.rod,
									this.cylinder});
			this.SymbolSize = new System.Drawing.Size(197, 122);
		}
		private NxtControl.GuiFramework.Group rod;
		private NxtControl.GuiFramework.Polygon polygon1;
		private NxtControl.GuiFramework.Group cylinder;
		private System.HMI.Symbols.Base.Execute<float> POS;
		private NxtControl.GuiFramework.Rectangle rectangle13;
		private NxtControl.GuiFramework.Rectangle rectangle14;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		#endregion
	}
}
