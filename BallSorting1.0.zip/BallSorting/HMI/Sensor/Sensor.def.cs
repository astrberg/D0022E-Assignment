using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Sensor_HMI;
#endregion Sensor_HMI;

#endregion Definitions;

