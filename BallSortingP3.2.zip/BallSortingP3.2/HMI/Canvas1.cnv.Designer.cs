﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 6:25 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Canvas1));
			this.pipeT1 = new NxtControl.GuiFramework.PipeT();
			this.pipeT2 = new NxtControl.GuiFramework.PipeT();
			this.pipe1 = new NxtControl.GuiFramework.Pipe();
			this.pipeT3 = new NxtControl.GuiFramework.PipeT();
			this.pipe2 = new NxtControl.GuiFramework.Pipe();
			this.pipe3 = new NxtControl.GuiFramework.Pipe();
			this.pipe4 = new NxtControl.GuiFramework.Pipe();
			this.Ball1 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball2 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball3 = new HMI.Main.Symbols.Ball.sDefault();
			this.Ball4 = new HMI.Main.Symbols.Ball.sDefault();
			this.ButtonReset = new HMI.Main.Symbols.ButtonReset.sDefault();
			this.LaserSensor = new HMI.Main.Symbols.Laser.sDefault();
			this.Gate1 = new HMI.Main.Symbols.CylinderGate.sDefault();
			this.Gate2 = new HMI.Main.Symbols.CylinderGate.sDefault();
			this.BufferBottom = new HMI.Main.Symbols.BufferBottom.sDefault();
			this.Buffer2 = new HMI.Main.Symbols.Buffer.sDefault();
			this.ButtGate2 = new HMI.Main.Symbols.Button.sDefault();
			this.Buffer1 = new HMI.Main.Symbols.Buffer.sDefault();
			this.ButtGate1 = new HMI.Main.Symbols.Button.sDefault();
			this.ButtEject = new HMI.Main.Symbols.Button.sDefault();
			this.CylinderEjector = new HMI.Main.Symbols.CylinderEjector.sDefault();
			this.RetractedSensor = new HMI.Main.Symbols.Sensor.sDefault();
			this.ExtendSensor = new HMI.Main.Symbols.Sensor.sDefault();
			this.ResetLabel = new NxtControl.GuiFramework.Label();
			this.label1 = new NxtControl.GuiFramework.Label();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.label3 = new NxtControl.GuiFramework.Label();
			this.HelpLabel = new NxtControl.GuiFramework.Label();
			this.MaterialSensor = new HMI.Main.Symbols.MaterialSensor.sDefault();
			this.GateBarOutline = new NxtControl.GuiFramework.Rectangle();
			this.helpText = new NxtControl.GuiFramework.FreeText();
			this.helpBackground = new NxtControl.GuiFramework.Rectangle();
			this.helpDialogBox = new NxtControl.GuiFramework.Group();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.ButtonHelp = new NxtControl.GuiFramework.DrawnButton();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.AutoDCBox1 = new NxtControl.GuiFramework.DrawnComboBox();
			this.AutoDCBox2 = new NxtControl.GuiFramework.DrawnComboBox();
			this.AutoDCBox3 = new NxtControl.GuiFramework.DrawnComboBox();
			this.AutoButton = new NxtControl.GuiFramework.TwoStateButton();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.line4 = new NxtControl.GuiFramework.Line();
			this.line5 = new NxtControl.GuiFramework.Line();
			this.line6 = new NxtControl.GuiFramework.Line();
			this.label4 = new NxtControl.GuiFramework.Label();
			this.label5 = new NxtControl.GuiFramework.Label();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line7 = new NxtControl.GuiFramework.Line();
			// 
			// pipeT1
			// 
			this.pipeT1.Angle = 90F;
			this.pipeT1.Bounds = new NxtControl.Drawing.RectF(((float)(266D)), ((float)(319D)), ((float)(328D)), ((float)(46D)));
			this.pipeT1.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipeT1.Name = "pipeT1";
			this.pipeT1.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipeT1.PipeWidth = 40;
			// 
			// pipeT2
			// 
			this.pipeT2.Bounds = new NxtControl.Drawing.RectF(((float)(349D)), ((float)(1D)), ((float)(46D)), ((float)(200D)));
			this.pipeT2.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipeT2.Name = "pipeT2";
			this.pipeT2.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipeT2.PipeWidth = 40;
			// 
			// pipe1
			// 
			this.pipe1.Bounds = new NxtControl.Drawing.RectF(((float)(286D)), ((float)(181D)), ((float)(66D)), ((float)(138D)));
			this.pipe1.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipe1.Name = "pipe1";
			this.pipe1.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipe1.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(352D, 181D),
									new NxtControl.Drawing.PointF(287D, 181D),
									new NxtControl.Drawing.PointF(286D, 319D)});
			this.pipe1.Width = 40;
			// 
			// pipeT3
			// 
			this.pipeT3.Angle = 90F;
			this.pipeT3.Bounds = new NxtControl.Drawing.RectF(((float)(266D)), ((float)(486D)), ((float)(328D)), ((float)(46D)));
			this.pipeT3.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipeT3.Name = "pipeT3";
			this.pipeT3.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipeT3.PipeWidth = 40;
			// 
			// pipe2
			// 
			this.pipe2.Bounds = new NxtControl.Drawing.RectF(((float)(9D)), ((float)(531D)), ((float)(277D)), ((float)(141D)));
			this.pipe2.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipe2.Name = "pipe2";
			this.pipe2.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipe2.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(286D, 531D),
									new NxtControl.Drawing.PointF(286D, 672D),
									new NxtControl.Drawing.PointF(9D, 672D)});
			this.pipe2.Width = 40;
			// 
			// pipe3
			// 
			this.pipe3.Bounds = new NxtControl.Drawing.RectF(((float)(286D)), ((float)(363D)), ((float)(0D)), ((float)(123D)));
			this.pipe3.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipe3.Name = "pipe3";
			this.pipe3.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipe3.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(286D, 363D),
									new NxtControl.Drawing.PointF(286D, 486D)});
			this.pipe3.Width = 40;
			// 
			// pipe4
			// 
			this.pipe4.Bounds = new NxtControl.Drawing.RectF(((float)(372D)), ((float)(0D)), ((float)(0D)), ((float)(39.999999999999993D)));
			this.pipe4.InnerColor = new NxtControl.Drawing.Color(((byte)(83)), ((byte)(83)), ((byte)(83)));
			this.pipe4.Name = "pipe4";
			this.pipe4.OuterColor = new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33)));
			this.pipe4.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(372D, 0D),
									new NxtControl.Drawing.PointF(372D, 39.999999999999993D)});
			this.pipe4.Width = 40;
			// 
			// Ball1
			// 
			this.Ball1.BeginInit();
			this.Ball1.AngleIgnore = false;
			this.Ball1.Name = "Ball1";
			this.Ball1.SecurityToken = ((uint)(4294967295u));
			this.Ball1.TagName = "BE4C58EC5BC1B409.Balls.Ball1";
			this.Ball1.EndInit();
			// 
			// Ball2
			// 
			this.Ball2.BeginInit();
			this.Ball2.AngleIgnore = false;
			this.Ball2.Name = "Ball2";
			this.Ball2.SecurityToken = ((uint)(4294967295u));
			this.Ball2.TagName = "BE4C58EC5BC1B409.Balls.Ball2";
			this.Ball2.EndInit();
			// 
			// Ball3
			// 
			this.Ball3.BeginInit();
			this.Ball3.AngleIgnore = false;
			this.Ball3.Name = "Ball3";
			this.Ball3.SecurityToken = ((uint)(4294967295u));
			this.Ball3.TagName = "BE4C58EC5BC1B409.Balls.Ball3";
			this.Ball3.EndInit();
			// 
			// Ball4
			// 
			this.Ball4.BeginInit();
			this.Ball4.AngleIgnore = false;
			this.Ball4.Name = "Ball4";
			this.Ball4.SecurityToken = ((uint)(4294967295u));
			this.Ball4.TagName = "BE4C58EC5BC1B409.Balls.Ball4";
			this.Ball4.EndInit();
			// 
			// ButtonReset
			// 
			this.ButtonReset.BeginInit();
			this.ButtonReset.AngleIgnore = false;
			this.ButtonReset.DesignTransformation = new NxtControl.Drawing.Matrix(1.0000000000000007D, 0D, 0D, 1.0000000000000002D, 729.96666666666681D, 620.24166666666656D);
			this.ButtonReset.Name = "ButtonReset";
			this.ButtonReset.SecurityToken = ((uint)(4294967295u));
			this.ButtonReset.TagName = "BE4C58EC5BC1B409.FB1";
			this.ButtonReset.Click += new System.EventHandler(this.ButtonResetClick);
			this.ButtonReset.EndInit();
			// 
			// LaserSensor
			// 
			this.LaserSensor.BeginInit();
			this.LaserSensor.AngleIgnore = false;
			this.LaserSensor.DesignTransformation = new NxtControl.Drawing.Matrix(0.95918367346938771D, 0D, 0D, 0.97916666666666663D, 267D, 110D);
			this.LaserSensor.Name = "LaserSensor";
			this.LaserSensor.SecurityToken = ((uint)(4294967295u));
			this.LaserSensor.TagName = "BE4C58EC5BC1B409.FB3.FB1";
			this.LaserSensor.EndInit();
			// 
			// Gate1
			// 
			this.Gate1.BeginInit();
			this.Gate1.AngleIgnore = false;
			this.Gate1.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 130D, 317D);
			this.Gate1.Name = "Gate1";
			this.Gate1.SecurityToken = ((uint)(4294967295u));
			this.Gate1.TagName = "BE4C58EC5BC1B409.Gate1";
			this.Gate1.EndInit();
			// 
			// Gate2
			// 
			this.Gate2.BeginInit();
			this.Gate2.AngleIgnore = false;
			this.Gate2.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 128D, 486D);
			this.Gate2.Name = "Gate2";
			this.Gate2.SecurityToken = ((uint)(4294967295u));
			this.Gate2.TagName = "BE4C58EC5BC1B409.Gate2";
			this.Gate2.EndInit();
			// 
			// BufferBottom
			// 
			this.BufferBottom.BeginInit();
			this.BufferBottom.AngleIgnore = false;
			this.BufferBottom.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 8D, 655D);
			this.BufferBottom.Name = "BufferBottom";
			this.BufferBottom.SecurityToken = ((uint)(4294967295u));
			this.BufferBottom.TagName = "BE4C58EC5BC1B409.PhysicsModel.FB2";
			this.BufferBottom.EndInit();
			// 
			// Buffer2
			// 
			this.Buffer2.BeginInit();
			this.Buffer2.AngleIgnore = false;
			this.Buffer2.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 307D, 492D);
			this.Buffer2.Name = "Buffer2";
			this.Buffer2.SecurityToken = ((uint)(4294967295u));
			this.Buffer2.TagName = "BE4C58EC5BC1B409.PhysicsModel.Buffer2";
			this.Buffer2.EndInit();
			// 
			// ButtGate2
			// 
			this.ButtGate2.BeginInit();
			this.ButtGate2.AngleIgnore = false;
			this.ButtGate2.DesignTransformation = new NxtControl.Drawing.Matrix(1.25D, 0D, 0D, 1.6666666666666665D, 720D, 485D);
			this.ButtGate2.Name = "ButtGate2";
			this.ButtGate2.SecurityToken = ((uint)(4294967295u));
			this.ButtGate2.TagName = "BE4C58EC5BC1B409.ButtGate2";
			this.ButtGate2.EndInit();
			// 
			// Buffer1
			// 
			this.Buffer1.BeginInit();
			this.Buffer1.AngleIgnore = false;
			this.Buffer1.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 306D, 326D);
			this.Buffer1.Name = "Buffer1";
			this.Buffer1.SecurityToken = ((uint)(4294967295u));
			this.Buffer1.TagName = "BE4C58EC5BC1B409.PhysicsModel.Buffer1";
			this.Buffer1.EndInit();
			// 
			// ButtGate1
			// 
			this.ButtGate1.BeginInit();
			this.ButtGate1.AngleIgnore = false;
			this.ButtGate1.DesignTransformation = new NxtControl.Drawing.Matrix(1.25D, 0D, 0D, 1.6666666666666663D, 719D, 319D);
			this.ButtGate1.Name = "ButtGate1";
			this.ButtGate1.SecurityToken = ((uint)(4294967295u));
			this.ButtGate1.TagName = "BE4C58EC5BC1B409.ButtGate1";
			this.ButtGate1.EndInit();
			// 
			// ButtEject
			// 
			this.ButtEject.BeginInit();
			this.ButtEject.AngleIgnore = false;
			this.ButtEject.DesignTransformation = new NxtControl.Drawing.Matrix(1.25D, 0D, 0D, 1.6666666666666665D, 721D, 158D);
			this.ButtEject.Name = "ButtEject";
			this.ButtEject.SecurityToken = ((uint)(4294967295u));
			this.ButtEject.TagName = "BE4C58EC5BC1B409.ButtonEject";
			this.ButtEject.EndInit();
			// 
			// CylinderEjector
			// 
			this.CylinderEjector.BeginInit();
			this.CylinderEjector.AngleIgnore = false;
			this.CylinderEjector.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 396D, 157D);
			this.CylinderEjector.Name = "CylinderEjector";
			this.CylinderEjector.SecurityToken = ((uint)(4294967295u));
			this.CylinderEjector.TagName = "BE4C58EC5BC1B409.Eject";
			this.CylinderEjector.EndInit();
			// 
			// RetractedSensor
			// 
			this.RetractedSensor.BeginInit();
			this.RetractedSensor.AngleIgnore = false;
			this.RetractedSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 594D, 136D);
			this.RetractedSensor.Name = "RetractedSensor";
			this.RetractedSensor.SecurityToken = ((uint)(4294967295u));
			this.RetractedSensor.TagName = "BE4C58EC5BC1B409.FB3.Retracted";
			this.RetractedSensor.EndInit();
			// 
			// ExtendSensor
			// 
			this.ExtendSensor.BeginInit();
			this.ExtendSensor.AngleIgnore = false;
			this.ExtendSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 484D, 136D);
			this.ExtendSensor.Name = "ExtendSensor";
			this.ExtendSensor.SecurityToken = ((uint)(4294967295u));
			this.ExtendSensor.TagName = "BE4C58EC5BC1B409.FB3.Extended";
			this.ExtendSensor.EndInit();
			// 
			// ResetLabel
			// 
			this.ResetLabel.AngleIgnore = true;
			this.ResetLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.ResetLabel.Bounds = new NxtControl.Drawing.RectF(((float)(732.12664794921875D)), ((float)(708.933349609375D)), ((float)(72.1933364868164D)), ((float)(16.458333969116211D)));
			this.ResetLabel.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.ResetLabel.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.ResetLabel.Name = "ResetLabel";
			this.ResetLabel.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.ResetLabel.Text = "RESET";
			this.ResetLabel.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.ResetLabel.TextAutoSizeHorizontalOffset = 10;
			this.ResetLabel.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.ResetLabel.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(732D)), ((float)(362D)), ((float)(120D)), ((float)(50D)));
			this.label1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "GATE 1";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(732D)), ((float)(528D)), ((float)(120D)), ((float)(50D)));
			this.label2.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "GATE 2";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(738D)), ((float)(200D)), ((float)(120D)), ((float)(50D)));
			this.label3.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "EJECT";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// HelpLabel
			// 
			this.HelpLabel.AngleIgnore = true;
			this.HelpLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.HelpLabel.Bounds = new NxtControl.Drawing.RectF(((float)(739.8900146484375D)), ((float)(92.933349609375D)), ((float)(130D)), ((float)(50D)));
			this.HelpLabel.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.HelpLabel.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.HelpLabel.Name = "HelpLabel";
			this.HelpLabel.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.HelpLabel.Text = "HELP";
			this.HelpLabel.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.HelpLabel.TextAutoSizeHorizontalOffset = 10;
			this.HelpLabel.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.HelpLabel.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// MaterialSensor
			// 
			this.MaterialSensor.BeginInit();
			this.MaterialSensor.AngleIgnore = false;
			this.MaterialSensor.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 323D, 200D);
			this.MaterialSensor.Name = "MaterialSensor";
			this.MaterialSensor.SecurityToken = ((uint)(4294967295u));
			this.MaterialSensor.TagName = "BE4C58EC5BC1B409.FB3.FB2";
			this.MaterialSensor.EndInit();
			// 
			// GateBarOutline
			// 
			this.GateBarOutline.Bounds = new NxtControl.Drawing.RectF(((float)(682D)), ((float)(1D)), ((float)(174D)), ((float)(765D)));
			this.GateBarOutline.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))));
			this.GateBarOutline.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.GateBarOutline.Name = "GateBarOutline";
			// 
			// helpText
			// 
			this.helpText.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.helpText.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular);
			this.helpText.Location = new NxtControl.Drawing.PointF(83.328333333333291D, 259D);
			this.helpText.Name = "helpText";
			this.helpText.Text = resources.GetString("helpText.Text");
			// 
			// helpBackground
			// 
			this.helpBackground.Bounds = new NxtControl.Drawing.RectF(((float)(81D)), ((float)(251D)), ((float)(564D)), ((float)(250D)));
			this.helpBackground.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))));
			this.helpBackground.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular);
			this.helpBackground.Name = "helpBackground";
			// 
			// helpDialogBox
			// 
			this.helpDialogBox.BeginInit();
			this.helpDialogBox.Name = "helpDialogBox";
			this.helpDialogBox.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.helpBackground,
									this.helpText});
			this.helpDialogBox.EndInit();
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(848D, 0D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(681D, 0D);
			// 
			// ButtonHelp
			// 
			this.ButtonHelp.Bounds = new NxtControl.Drawing.RectF(((float)(707D)), ((float)(25D)), ((float)(120D)), ((float)(70D)));
			this.ButtonHelp.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(32)), ((byte)(214)), ((byte)(88))));
			this.ButtonHelp.ButtonPushedBrush = new NxtControl.Drawing.Brush();
			this.ButtonHelp.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.ButtonHelp.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.ButtonHelp.Name = "ButtonHelp";
			this.ButtonHelp.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.ButtonHelp.Radius = 4D;
			this.ButtonHelp.Text = "SHOW";
			this.ButtonHelp.TextDisabledColor = new NxtControl.Drawing.Color(((byte)(234)), ((byte)(22)), ((byte)(30)));
			this.ButtonHelp.Use3DEffect = false;
			this.ButtonHelp.Click += new System.EventHandler(this.ButtonHelpClick);
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(594D)), ((float)(480D)), ((float)(10D)), ((float)(60D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft));
			this.rectangle1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(593D)), ((float)(312D)), ((float)(10D)), ((float)(60D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft));
			this.rectangle2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle2.Name = "rectangle2";
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(-7D)), ((float)(641D)), ((float)(17D)), ((float)(60D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalRight));
			this.rectangle3.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle3.Name = "rectangle3";
			// 
			// AutoDCBox1
			// 
			this.AutoDCBox1.Bounds = new NxtControl.Drawing.RectF(((float)(583D)), ((float)(621D)), ((float)(60D)), ((float)(25D)));
			this.AutoDCBox1.Brush = new NxtControl.Drawing.Brush("ComboBoxBrush");
			this.AutoDCBox1.Items.AddRange(new string[] {
									"0",
									"1",
									"2",
									"3",
									"4",
									"5",
									"6",
									"7"});
			this.AutoDCBox1.Name = "AutoDCBox1";
			this.AutoDCBox1.Pen = new NxtControl.Drawing.Pen("ComboBoxPen");
			this.AutoDCBox1.SelectedIndex = -1;
			this.AutoDCBox1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// AutoDCBox2
			// 
			this.AutoDCBox2.Bounds = new NxtControl.Drawing.RectF(((float)(583D)), ((float)(657D)), ((float)(60D)), ((float)(25D)));
			this.AutoDCBox2.Brush = new NxtControl.Drawing.Brush("ComboBoxBrush");
			this.AutoDCBox2.Items.AddRange(new string[] {
									"0",
									"1",
									"2",
									"3",
									"4",
									"5",
									"6",
									"7"});
			this.AutoDCBox2.Name = "AutoDCBox2";
			this.AutoDCBox2.Pen = new NxtControl.Drawing.Pen("ComboBoxPen");
			this.AutoDCBox2.SelectedIndex = -1;
			this.AutoDCBox2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// AutoDCBox3
			// 
			this.AutoDCBox3.Bounds = new NxtControl.Drawing.RectF(((float)(583D)), ((float)(693D)), ((float)(60D)), ((float)(25D)));
			this.AutoDCBox3.Brush = new NxtControl.Drawing.Brush("ComboBoxBrush");
			this.AutoDCBox3.Items.AddRange(new string[] {
									"0",
									"1",
									"2",
									"3",
									"4",
									"5",
									"6",
									"7"});
			this.AutoDCBox3.Name = "AutoDCBox3";
			this.AutoDCBox3.Pen = new NxtControl.Drawing.Pen("ComboBoxPen");
			this.AutoDCBox3.SelectedIndex = -1;
			this.AutoDCBox3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// AutoButton
			// 
			this.AutoButton.Bounds = new NxtControl.Drawing.RectF(((float)(367D)), ((float)(630D)), ((float)(180D)), ((float)(80D)));
			this.AutoButton.DrawStyle = NxtControl.GuiFramework.TwoStateButton.ButtonDrawStyle.CheckBox;
			this.AutoButton.FalseBrush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(32)), ((byte)(214)), ((byte)(88))));
			this.AutoButton.FalseText = "START";
			this.AutoButton.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.AutoButton.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.AutoButton.Name = "AutoButton";
			this.AutoButton.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.AutoButton.Radius = 8D;
			this.AutoButton.TextDisabledColor = new NxtControl.Drawing.Color("Black");
			this.AutoButton.TrueBrush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(233)), ((byte)(21)), ((byte)(31))));
			this.AutoButton.TrueText = "IN PROGRESS...";
			this.AutoButton.Use3DEffect = false;
			this.AutoButton.CheckedChanged += new System.EventHandler(this.AutoButtonCheckedChanged);
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(329D)), ((float)(590D)), ((float)(355D)), ((float)(177D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(33)), ((byte)(33)), ((byte)(33))));
			this.rectangle4.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle4.Name = "rectangle4";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(682D, 764D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(683D, 0D);
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(851D, 590D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(329D, 590D);
			// 
			// line5
			// 
			this.line5.EndPoint = new NxtControl.Drawing.PointF(328D, 765D);
			this.line5.Name = "line5";
			this.line5.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line5.StartPoint = new NxtControl.Drawing.PointF(328D, 589D);
			// 
			// line6
			// 
			this.line6.EndPoint = new NxtControl.Drawing.PointF(850D, 136D);
			this.line6.Name = "line6";
			this.line6.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line6.StartPoint = new NxtControl.Drawing.PointF(683D, 136D);
			// 
			// label4
			// 
			this.label4.AngleIgnore = true;
			this.label4.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label4.Bounds = new NxtControl.Drawing.RectF(((float)(567D)), ((float)(733D)), ((float)(100D)), ((float)(16D)));
			this.label4.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.label4.Name = "label4";
			this.label4.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label4.Text = "SETTINGS";
			this.label4.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.label4.TextAutoSizeHorizontalOffset = 10;
			this.label4.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label4.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label5
			// 
			this.label5.AngleIgnore = true;
			this.label5.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label5.Bounds = new NxtControl.Drawing.RectF(((float)(389D)), ((float)(733D)), ((float)(150D)), ((float)(16D)));
			this.label5.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.label5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
			this.label5.Name = "label5";
			this.label5.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label5.Text = "AUTO MODE";
			this.label5.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.label5.TextAutoSizeHorizontalOffset = 10;
			this.label5.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label5.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(848D, 764D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(849D, 0D);
			// 
			// line7
			// 
			this.line7.EndPoint = new NxtControl.Drawing.PointF(849D, 764D);
			this.line7.Name = "line7";
			this.line7.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(80)), ((byte)(80)), ((byte)(80))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line7.StartPoint = new NxtControl.Drawing.PointF(328D, 764D);
			// 
			// Canvas1
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(850D)), ((float)(765D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210))));
			this.Name = "Canvas1";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.rectangle4,
									this.rectangle1,
									this.rectangle2,
									this.pipe2,
									this.pipeT1,
									this.pipeT2,
									this.pipe1,
									this.pipeT3,
									this.pipe3,
									this.pipe4,
									this.Ball1,
									this.Ball2,
									this.Ball3,
									this.Ball4,
									this.LaserSensor,
									this.MaterialSensor,
									this.Gate1,
									this.Gate2,
									this.Buffer2,
									this.Buffer1,
									this.CylinderEjector,
									this.RetractedSensor,
									this.ExtendSensor,
									this.BufferBottom,
									this.helpDialogBox,
									this.GateBarOutline,
									this.ButtEject,
									this.label3,
									this.line1,
									this.ButtonReset,
									this.ResetLabel,
									this.ButtGate1,
									this.label1,
									this.ButtGate2,
									this.label2,
									this.HelpLabel,
									this.ButtonHelp,
									this.rectangle3,
									this.AutoDCBox1,
									this.AutoDCBox2,
									this.AutoDCBox3,
									this.AutoButton,
									this.line3,
									this.line4,
									this.line5,
									this.line6,
									this.label4,
									this.label5,
									this.line2,
									this.line7});
			this.Size = new System.Drawing.Size(850, 765);
		}
		private NxtControl.GuiFramework.Label label5;
		private NxtControl.GuiFramework.Label label4;
		private NxtControl.GuiFramework.Line line7;
		private NxtControl.GuiFramework.Line line6;
		private NxtControl.GuiFramework.Line line5;
		private NxtControl.GuiFramework.Line line4;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.TwoStateButton AutoButton;
		private NxtControl.GuiFramework.DrawnComboBox AutoDCBox3;
		private NxtControl.GuiFramework.DrawnComboBox AutoDCBox2;
		private NxtControl.GuiFramework.DrawnComboBox AutoDCBox1;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.DrawnButton ButtonHelp;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.FreeText helpText;
		private NxtControl.GuiFramework.Rectangle helpBackground;
		private NxtControl.GuiFramework.Group helpDialogBox;
		private NxtControl.GuiFramework.Rectangle GateBarOutline;
		private NxtControl.GuiFramework.Label HelpLabel;
		private NxtControl.GuiFramework.Label label3;
		private NxtControl.GuiFramework.Label label2;
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Label ResetLabel;
		private HMI.Main.Symbols.Sensor.sDefault ExtendSensor;
		private HMI.Main.Symbols.Sensor.sDefault RetractedSensor;
		private HMI.Main.Symbols.CylinderEjector.sDefault CylinderEjector;
		private HMI.Main.Symbols.Button.sDefault ButtEject;
		private HMI.Main.Symbols.Button.sDefault ButtGate1;
		private HMI.Main.Symbols.Buffer.sDefault Buffer1;
		private HMI.Main.Symbols.Button.sDefault ButtGate2;
		private HMI.Main.Symbols.Buffer.sDefault Buffer2;
		private HMI.Main.Symbols.BufferBottom.sDefault BufferBottom;
		private HMI.Main.Symbols.CylinderGate.sDefault Gate2;
		private HMI.Main.Symbols.CylinderGate.sDefault Gate1;
		private HMI.Main.Symbols.MaterialSensor.sDefault MaterialSensor;
		private HMI.Main.Symbols.Laser.sDefault LaserSensor;
		private HMI.Main.Symbols.ButtonReset.sDefault ButtonReset;
		private HMI.Main.Symbols.Ball.sDefault Ball4;
		private HMI.Main.Symbols.Ball.sDefault Ball3;
		private HMI.Main.Symbols.Ball.sDefault Ball2;
		private HMI.Main.Symbols.Ball.sDefault Ball1;
		private NxtControl.GuiFramework.Pipe pipe4;
		private NxtControl.GuiFramework.Pipe pipe3;
		private NxtControl.GuiFramework.Pipe pipe2;
		private NxtControl.GuiFramework.PipeT pipeT3;
		private NxtControl.GuiFramework.Pipe pipe1;
		private NxtControl.GuiFramework.PipeT pipeT2;
		private NxtControl.GuiFramework.PipeT pipeT1;
		#endregion
	}
}
