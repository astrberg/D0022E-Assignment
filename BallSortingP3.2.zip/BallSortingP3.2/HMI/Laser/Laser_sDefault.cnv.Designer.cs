﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/15/2016
 * Time: 10:15 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Laser
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			this.BallInChute = new System.HMI.Symbols.Base.Led<bool>();
			this.laser = new NxtControl.GuiFramework.Line();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			// 
			// BallInChute
			// 
			this.BallInChute.BeginInit();
			this.BallInChute.AngleIgnore = false;
			this.BallInChute.ColorFrame = new NxtControl.Drawing.Color("Black");
			this.BallInChute.DesignTransformation = new NxtControl.Drawing.Matrix(2.5000000000000009D, 0D, 0D, 2.5D, 62.999999999999986D, 45.999999999999993D);
			this.BallInChute.FrameSize = 33F;
			this.BallInChute.Name = "BallInChute";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color(((byte)(122)), ((byte)(78)), ((byte)(43))));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.BallInChute.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.BallInChute.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.BallInChute.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.BallInChute.TagName = "BallInChute";
			this.BallInChute.EndInit();
			// 
			// laser
			// 
			this.laser.EndPoint = new NxtControl.Drawing.PointF(60D, 63D);
			this.laser.Name = "laser";
			this.laser.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(234)), ((byte)(22)), ((byte)(30))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.laser.StartPoint = new NxtControl.Drawing.PointF(60D, 63D);
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(38D)), ((float)(22D)), ((float)(50D)), ((float)(50D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(179)), ((byte)(179)), ((byte)(179))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.DiagonalLeftTop));
			this.rectangle1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(55D)), ((float)(60D)), ((float)(10D)), ((float)(20D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Black"));
			this.rectangle2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle2.Name = "rectangle2";
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.rectangle1,
									this.BallInChute,
									this.laser,
									this.rectangle2});
			this.SymbolSize = new System.Drawing.Size(600, 400);
		}
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Line laser;
		private System.HMI.Symbols.Base.Led<bool> BallInChute;
		#endregion
	}
}
