using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region Laser_HMI;
#endregion Laser_HMI;

#endregion Definitions;

