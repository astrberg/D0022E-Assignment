﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/15/2016
 * Time: 10:57 AM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
