﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 6:25 PM
 * 
 */

using System;
using System.Drawing;
using Microsoft.VisualBasic;
using NxtControl.GuiFramework;
using System.Timers;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Canvas1.
	/// </summary>
	public partial class Canvas1 : NxtControl.GuiFramework.HMICanvas
	{
		public Canvas1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			helpDialogBox.Visible = false;
		}

		
		void ButtonHelpClick(object sender, EventArgs e)
		{
		  if(this.ButtonHelp.Text == "SHOW") {
		    this.ButtonHelp.Text = "HIDE";
		    this.ButtonHelp.Brush.Color = "210,1,23";
		    helpDialogBox.Visible = true;
		    
		  } else {
		    this.ButtonHelp.Text = "SHOW";
		    this.ButtonHelp.Brush.Color = "29,185,84";
		    helpDialogBox.Visible = false;
		  }
		}
		
		void BarClick(object sender, EventArgs e)
		{
			
		}
		
		void ButtonResetClick(object sender, EventArgs e)
		{
			DialogResult confirmationBox = MessageBox.Show("Do you want to reset?", "Reset system", MessageBoxButtons.YesNo);
		  if(confirmationBox == DialogResult.Yes) {
		    this.ButtonReset.FireEvent_CHG();
			  this.ButtGate1.FireEvent_CHG(false);
  	    this.ButtGate2.FireEvent_CHG(false);
  	    this.ButtEject.FireEvent_CHG(false);
  	    
		  }
		}
	}
}
