/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;
#region #ButtonReset2_HMI;

namespace HMI.Main.Symbols.ButtonReset2
{

  public class CHGEventArgs : System.EventArgs
  {
    public CHGEventArgs()
    {
    }

  }

}

namespace HMI.Main.Symbols.ButtonReset2
{
  partial class sDefault
  {
    public bool FireEvent_CHG()
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {});
    }
    public bool FireEvent_CHG(HMI.Main.Symbols.ButtonReset2.CHGEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}
#endregion #ButtonReset2_HMI;

#endregion Definitions;
