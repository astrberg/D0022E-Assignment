﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.ButtonReset
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ellipse1 = new NxtControl.GuiFramework.Ellipse();
			this.arc1 = new NxtControl.GuiFramework.Arc();
			this.polygon1 = new NxtControl.GuiFramework.Polygon();
			// 
			// ellipse1
			// 
			this.ellipse1.Bounds = new NxtControl.Drawing.RectF(((float)(44D)), ((float)(15D)), ((float)(70D)), ((float)(70D)));
			this.ellipse1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(29)), ((byte)(185)), ((byte)(84))));
			this.ellipse1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ellipse1.Name = "ellipse1";

			// 
			// arc1
			// 
			this.arc1.Bounds = new NxtControl.Drawing.RectF(((float)(59D)), ((float)(29D)), ((float)(40D)), ((float)(40D)));
			this.arc1.Center = new NxtControl.Drawing.PointF(79D, 49D);
			this.arc1.Name = "arc1";
			this.arc1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 3F, NxtControl.Drawing.DashStyle.Solid);
			this.arc1.RadiusX = 20D;
			this.arc1.RadiusY = 20D;
			this.arc1.StartAngle = 109.65382405805332D;
			this.arc1.SweepAngle = 270D;
			// 
			// polygon1
			// 
			this.polygon1.Bounds = new NxtControl.Drawing.RectF(((float)(68D)), ((float)(58D)), ((float)(19D)), ((float)(19D)));
			this.polygon1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.polygon1.Closed = true;
			this.polygon1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.polygon1.Name = "polygon1";
			this.polygon1.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(77D, 58D),
									new NxtControl.Drawing.PointF(68D, 77D),
									new NxtControl.Drawing.PointF(87D, 75D)});
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.ellipse1,
									this.arc1,
									this.polygon1});
			this.SymbolSize = new System.Drawing.Size(159, 105);
		}
		private NxtControl.GuiFramework.Polygon polygon1;
		private NxtControl.GuiFramework.Arc arc1;
		private NxtControl.GuiFramework.Ellipse ellipse1;
		#endregion
	}
}
