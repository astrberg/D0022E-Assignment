using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region CylinderEjector_HMI;
#endregion CylinderEjector_HMI;

#endregion Definitions;

