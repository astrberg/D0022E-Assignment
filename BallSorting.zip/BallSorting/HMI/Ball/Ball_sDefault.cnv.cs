﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/8/2016
 * Time: 3:44 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Ball
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
	  bool matChanged = false;
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
      this.INITC_Fired += INITC_Fired_EventHandler;
      this.REQ_Fired += REQ_Fired_EventHandler;
		}
		
		void PosXValueChanged(object sender, ValueChangedEventArgs e)
		{
			NxtControl.Drawing.PointF newPos = ball.Location;
		  float posX = (float)e.Value;
		  double relposX = posX + 0.0d;
			newPos.X = relposX;
			ball.Location = newPos;
		}
		
		void PosYValueChanged(object sender, ValueChangedEventArgs e)
		{
			NxtControl.Drawing.PointF newPos = ball.Location;
		  float posY = (float)e.Value;
		  double relposY = posY + 0.0d;
			newPos.Y = relposY;
			ball.Location = newPos;
		}		
		
		void INITC_Fired_EventHandler(object sender, HMI.Main.Symbols.Ball.INITCEventArgs ea)
		{
		  Random rnd = new Random(DateTime.Now.Millisecond);
		  int material = rnd.Next(1,4);
		  switch (material)
			{
		    case 1:
		      ball.BrushColor = Color.Black;
		      break;
		    case 2:
		      ball.BrushColor = Color.Orange;
		      break;
		    case 3:
		      ball.BrushColor = Color.Gray;
		      break;
			}
		  matChanged = true;
		  this.FireEvent_CNF((short)material);
		}
		
		void REQ_Fired_EventHandler(object sender, HMI.Main.Symbols.Ball.REQEventArgs ea)
		{
		  double posY = (double)ea.PosY;
		  if ((posY < 10) & !(matChanged))
		  {
  		  Random rnd = new Random(DateTime.Now.Millisecond);
  		  int material = rnd.Next(1,4);
  		  switch (material)
  			{
  		    case 1:
  		      ball.BrushColor = Color.Black;
  		      break;
  		    case 2:
  		      ball.BrushColor = Color.Orange;
  		      break;
  		    case 3:
  		      ball.BrushColor = Color.Gray;
  		      break;
  			}
  		  this.FireEvent_MatCHG((short)material);
  		  matChanged = true;
		  }
		  
		  if ((posY > 50) & matChanged)
		  {
		    matChanged = false;
		  }
		}
	}
}
