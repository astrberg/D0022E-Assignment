﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/26/2016
 * Time: 6:06 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.Sensor
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			this.SensorRear = new System.HMI.Symbols.Base.Led<bool>();
			// 
			// SensorRear
			// 
			this.SensorRear.BeginInit();
			this.SensorRear.AngleIgnore = false;
			this.SensorRear.ColorFrame = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.SensorRear.DesignTransformation = new NxtControl.Drawing.Matrix(2, 0, 0, 2, 30, 29);
			this.SensorRear.Name = "SensorRear";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color(((byte)(122)), ((byte)(78)), ((byte)(43))));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.SensorRear.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.SensorRear.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.SensorRear.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.SensorRear.Shape = System.HMI.Symbols.Base.LedShape.Rectangle;
			this.SensorRear.TagName = "SensorRear";
			this.SensorRear.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.SensorRear});
			this.SymbolSize = new System.Drawing.Size(441, 333);
		}
		private System.HMI.Symbols.Base.Led<bool> SensorRear;
		#endregion
	}
}
