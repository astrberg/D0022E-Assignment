﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/15/2016
 * Time: 10:57 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.MaterialSensor
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary5 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary6 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary4 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary8 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary9 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary7 = new NxtControl.GuiFramework.PropertyDictionary();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.Capacitive = new System.HMI.Symbols.Base.Led<bool>();
			this.Optical = new System.HMI.Symbols.Base.Led<bool>();
			this.Inductive = new System.HMI.Symbols.Base.Led<bool>();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(27)), ((float)(28)), ((float)(60)), ((float)(20)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.rectangle1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(72)), ((float)(14)), ((float)(8)), ((float)(70)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.rectangle2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle2.Name = "rectangle2";
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(27)), ((float)(53)), ((float)(60)), ((float)(20)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.rectangle3.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle3.Name = "rectangle3";
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(27)), ((float)(78)), ((float)(60)), ((float)(20)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))));
			this.rectangle4.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle4.Name = "rectangle4";
			// 
			// Capacitive
			// 
			this.Capacitive.BeginInit();
			this.Capacitive.AngleIgnore = false;
			this.Capacitive.ColorFrame = new NxtControl.Drawing.Color("Black");
			this.Capacitive.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 43, 37);
			this.Capacitive.Name = "Capacitive";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color(((byte)(122)), ((byte)(78)), ((byte)(43))));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Capacitive.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.Capacitive.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Capacitive.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.Capacitive.TagName = "Capacitive";
			this.Capacitive.EndInit();
			// 
			// Optical
			// 
			this.Optical.BeginInit();
			this.Optical.AngleIgnore = false;
			this.Optical.ColorFrame = new NxtControl.Drawing.Color("Black");
			this.Optical.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 43, 63);
			this.Optical.Name = "Optical";
			propertyDictionary5.Add("Color", new NxtControl.Drawing.Color(((byte)(122)), ((byte)(78)), ((byte)(43))));
			propertyDictionary6.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Optical.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary5));
			this.Optical.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary6));
			propertyDictionary4.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Optical.Ranges.DefaultPropertyValues = propertyDictionary4;
			this.Optical.TagName = "Optical";
			this.Optical.EndInit();
			// 
			// Inductive
			// 
			this.Inductive.BeginInit();
			this.Inductive.AngleIgnore = false;
			this.Inductive.ColorFrame = new NxtControl.Drawing.Color("Black");
			this.Inductive.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 43, 88);
			this.Inductive.Name = "Inductive";
			propertyDictionary8.Add("Color", new NxtControl.Drawing.Color(((byte)(122)), ((byte)(78)), ((byte)(43))));
			propertyDictionary9.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Inductive.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary8));
			this.Inductive.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary9));
			propertyDictionary7.Add("Color", new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.Inductive.Ranges.DefaultPropertyValues = propertyDictionary7;
			this.Inductive.TagName = "Inductive";
			this.Inductive.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.rectangle1,
									this.rectangle2,
									this.rectangle3,
									this.rectangle4,
									this.Capacitive,
									this.Optical,
									this.Inductive});
			this.SymbolSize = new System.Drawing.Size(600, 400);
		}
		private System.HMI.Symbols.Base.Led<bool> Inductive;
		private System.HMI.Symbols.Base.Led<bool> Optical;
		private System.HMI.Symbols.Base.Led<bool> Capacitive;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		#endregion
	}
}
