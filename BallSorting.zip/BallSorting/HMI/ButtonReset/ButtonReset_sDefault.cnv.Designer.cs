﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 6/7/2016
 * Time: 11:22 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.ButtonReset
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.ellipse1 = new NxtControl.GuiFramework.Ellipse();
			// 
			// ellipse1
			// 
			this.ellipse1.Bounds = new NxtControl.Drawing.RectF(((float)(41)), ((float)(16)), ((float)(70)), ((float)(70)));
			this.ellipse1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.ellipse1.ImageStream = ((System.IO.MemoryStream)(resources.GetObject("ellipse1.ImageStream")));
			this.ellipse1.Name = "ellipse1";
			this.ellipse1.Click += new System.EventHandler(this.Ellipse1Click);
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.ellipse1});
			this.SymbolSize = new System.Drawing.Size(159, 105);
		}
		private NxtControl.GuiFramework.Ellipse ellipse1;
		#endregion
	}
}
